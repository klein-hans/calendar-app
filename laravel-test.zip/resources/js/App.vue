<template>
  <div>
    <calendar-event></calendar-event>
  </div>
</template>


<script>
  import CalendarEvent from './components/CalendarEvent.vue'
  
  export default {

  }
</script>

<style>

</style>