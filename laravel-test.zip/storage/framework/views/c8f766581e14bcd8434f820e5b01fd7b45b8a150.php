
<?php /**PATH C:\xampp\htdocs\laravel-test\resources\views/welcome.blade.php ENDPATH**/ ?>