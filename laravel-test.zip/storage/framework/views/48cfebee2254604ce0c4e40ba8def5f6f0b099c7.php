<?php $__env->startSection('title', 'Calendar'); ?>



<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-test\resources\views/calendar.blade.php ENDPATH**/ ?>